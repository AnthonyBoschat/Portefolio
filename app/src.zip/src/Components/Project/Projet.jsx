import React from "react";

function Projet(){

    return(
        <h1>Projet</h1>
    )
}

export default Projet;