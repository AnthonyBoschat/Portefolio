import React, { useEffect, useRef, useState } from "react";

function Contact(){

    return(
        <h1>Contact</h1>
    )
}

export default Contact;